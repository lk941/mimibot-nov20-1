export class parentPortal {
    username: string = '';
    password: string = '';
}
