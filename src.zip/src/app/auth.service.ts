import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, from } from 'rxjs';
import { parentPortal } from './parent-login/loginthings/parentPortal';
import { ParentportalService } from './parent-login/services/parentportal.service';
import { NG_MODEL_WITH_FORM_CONTROL_WARNING } from '@angular/forms/src/directives';

// import * as express from 'express';
// const bodyParser = require('body-parser');
// import * as jwt from 'jsonwebtoken';
// import * as fs from "fs"; PROBLEM CODE


@Injectable({
  providedIn: 'root'
})
export class AuthService {
  Logined: boolean = false;
  parentUsers: any[];

  TestHeyo: boolean = false;

  FirstTimeSetUp() {
    console.log("Booting...");
  //   if (this.TestHeyo == false){
  //     this.service.getParent().subscribe(list => {
  //     this.parentUsers = list.map(item => {
  //       return {
  //         ...item.payload.val()
  //       }
  //     })
  //   })
  //   console.log(this.parentUsers);
  //   this.TestHeyo = true
  //   console.log("Yes, It is true now.");
  // }
  //   else {
  //     console.log("smile");
  //     // Do Nothing
  //   }
    //DIAGNOSTICS
    this.parentUsers = this.service.getAllParentData();
    console.log(this.parentUsers);
  
  }
  Login(user: string, password: string){
    console.log("Login is running");

    // this.parentPortalService.update(this.parentportal, this.key);
    console.log("Entered into the DB!!");
    
    console.log(this.parentUsers);
    for (var i = 0; i < this.parentUsers.length; ++i) {
      var pCurrentUser = this.parentUsers[i];

      if (user == pCurrentUser.Username && password == pCurrentUser.Password) {
        console.log('Putting into Session Storage');
        //console.log(pCurrentUser);
        let key = "User"
        sessionStorage.setItem(key,pCurrentUser.key);
        console.log(pCurrentUser)
        sessionStorage.setItem('userType',pCurrentUser.userType);
        this.Logined = true;
        return; 
      } else {
        console.log("No User Records Found.")
      }
    }
  
  
}
  Logout(){
    let key = "User";
    sessionStorage.removeItem(key);
    //sessionStorage.removeItem('UserType');
    // NEED TO USE IT FIRST, CREATE BUTTON IN NAV BAR
    this.Logined = false;
    console.log(this.Logined);
  }
  isAuthenticated() {
    console.log(this.Logined);
    return this.Logined;
  }
  
  constructor(private service: ParentportalService) { }
}
