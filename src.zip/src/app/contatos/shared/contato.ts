export class Contato {
    Student: string ='';
    Name: string ='';
    Date: string ='';
    CompletionStatus: string ='';
}


