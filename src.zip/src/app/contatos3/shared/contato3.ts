export class Contato3 {
    Qn: string = '';
    Ans: string = '';
}
