import { Component, OnInit } from '@angular/core';
import {NavService} from './nav.service'

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss']
})
export class NavComponent implements OnInit {

  appTitle = 'Teacher Portal';
  // OR (either will work)
  visible: boolean

  constructor(private nav: NavService) { }

  ngOnInit() {
  }

}
