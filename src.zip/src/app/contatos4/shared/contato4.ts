export class Contato4 {
    msg: string = '';
    date: string = '';
}
