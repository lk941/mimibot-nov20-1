function ok(string) {

    console.log(bullyNet.run(string));
}
