import { Component, OnInit } from '@angular/core';
import { NavService } from '../nav/nav.service';
import { ParentPortal } from '../parent-login/services/parentportal';
import { ParentportalService } from '../parent-login/services/parentportal.service';
import { ParentportalDataService } from '../parent-login/services/parentportal-data.service';
import { Observable, of } from 'rxjs';
import { Router, Params } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { AuthService } from '../auth.service';

declare function btnSignUpClicked([]): string;


@Component({
  selector: 'app-parent-login',
  templateUrl: './parent-login.component.html',
  styleUrls: ['./parent-login.component.scss']
})
export class ParentLoginComponent implements OnInit {

  parentportal: ParentPortal
  key: string="";
  success=false;
  parentPortalArray = [];
  parentUsers = [];

  constructor(private AuthService: AuthService,private router: Router, private route: ActivatedRoute, private parentPortalService: ParentportalService, private parentPortalDataService: ParentportalDataService, private nav: NavService) {}
  
  ngOnInit() {
    this.nav.show();


    this.parentportal = new ParentPortal();
    this.parentPortalDataService.currentParentPortal.subscribe(data => {
      if (data.parentportal && data.key) {
        this.parentportal = new ParentPortal();
        this.parentportal.Username = data.parentportal.Username;
        this.parentportal.Password = data.parentportal.Password;
        this.key = data.key;
      }
    })

    this.AuthService.FirstTimeSetUp();
  }

parentUsername: string;

  onSubmitLogIn() {
    console.log("Login is running");
    //stop if form is wrong
    
    console.log("Login Step 2 is running");
    
    this.AuthService.Login(this.parentportal.Username, this.parentportal.Password);
    
    return;
  }

  // public hashPwd() {
  //   btnSignUpClicked(this.parentPortalArray);
  // }
}
