import { Contato4 } from './contato4';

describe('Contato4', () => {
  it('should create an instance', () => {
    expect(new Contato4()).toBeTruthy();
  });
});
