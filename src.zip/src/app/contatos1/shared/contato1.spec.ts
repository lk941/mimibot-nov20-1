import { Contato1 } from './contato1';

describe('Contato1', () => {
  it('should create an instance', () => {
    expect(new Contato1()).toBeTruthy();
  });
});
