import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpModule } from '@angular/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import { HttpClientModule, /* other http imports */ } from "@angular/common/http";
import { ContatoDataService } from './contatos/shared/contato-data.service';
import { ContatoService } from './contatos/shared/contato.service';
import { AutomlService } from './contatos1/bully-insight/automl.service';

import {environment} from '../environments/environment';
import {AngularFireModule} from '@angular/fire';
import {AngularFireDatabaseModule} from '@angular/fire/database';
import { EditComponent } from './contatos/edit/edit.component';
import { ListComponent } from './contatos/list/list.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NavComponent } from './nav/nav.component';
import { HomeComponent } from './home/home.component';
import { HomeworkComponent } from './homework/homework.component';
import { QuizComponent } from './quiz/quiz.component';
import { BullyReportComponent } from './bully-report/bully-report.component';
import { BullyDetailsComponent } from './bully-details/bully-details.component';
import { BullyInsightComponent } from './contatos1/bully-insight/bully-insight.component';
import { Edit1Component } from './contatos1/edit1/edit1.component';
import { List1Component } from './contatos1/list1/list1.component';
import { Edit2Component } from './contatos2/edit2/edit2.component';
import { List2Component } from './contatos2/list2/list2.component';
import { Edit3Component } from './contatos3/edit3/edit3.component';
import { List3Component } from './contatos3/list3/list3.component';
import { ScoreDetailsComponent } from './pcrassesment/score-details/score-details.component';
import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { ConfirmationDialogService } from './confirmation-dialog/confirmation-dialog.service';
import { TagCloudComponent } from './tag-cloud/tag-cloud.component';

import{ jqxTagCloudComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxtagcloud';  
import { jqxColorPickerComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxcolorpicker';
import { jqxDropDownButtonComponent } from 'jqwidgets-scripts/jqwidgets-ts/angular_jqxdropdownbutton';

import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {NgxPaginationModule} from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { Ng2OrderModule } from 'ng2-order-pipe';
import { OAuthModule } from 'angular-oauth2-oidc';
import { NgCircleProgressModule } from 'ng-circle-progress';

import { UniquePipe } from './pcrassesment/unique.pipe';
import { ParentPortalComponent } from './parent-portal/parent-portal.component';
import { ParentLoginComponent } from './parent-login/parent-login.component';
import { ParentportalsignComponent } from './parentportalsign/parentportalsign.component';
import { ChildReportComponent } from './child-report/child-report.component';
import { ChildInsightComponent } from './child-insight/child-insight.component';
import { List4Component } from './contatos4/list4/list4.component';

@NgModule({
  declarations: [
    AppComponent,
    EditComponent,
    ListComponent,
    NavComponent,
    HomeComponent,
    HomeworkComponent,
    QuizComponent,
    BullyReportComponent,
    BullyDetailsComponent,
    BullyInsightComponent,
    Edit1Component,
    List1Component,
    Edit2Component,
    List2Component,
    Edit3Component,
    List3Component,
    ScoreDetailsComponent,
    ConfirmationDialogComponent,
    TagCloudComponent,
    jqxTagCloudComponent,
    jqxColorPickerComponent,
    jqxDropDownButtonComponent,
    UniquePipe,
    ParentPortalComponent,
    ParentLoginComponent,
    ParentportalsignComponent,
    ChildReportComponent,
    ChildInsightComponent,
    List4Component,
  ],
  entryComponents: [ConfirmationDialogComponent],
  imports: [
    BrowserModule,
    HttpModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    AngularFireModule.initializeApp(environment.firebase),
    AngularFireDatabaseModule,
    HttpClientModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    Ng2OrderModule,
    NgbModule.forRoot(),
    OAuthModule.forRoot(),
    NgCircleProgressModule.forRoot({
      // set defaults here
      radius: 100,
      outerStrokeWidth: 16,
      innerStrokeWidth: 8,
      outerStrokeColor: "#78C000",
      innerStrokeColor: "#C7E596",
      animationDuration: 300,
    }),
  ],
  providers: [ContatoService,ContatoDataService,ConfirmationDialogService,AutomlService],
  bootstrap: [AppComponent]
})

export class AppModule { }
