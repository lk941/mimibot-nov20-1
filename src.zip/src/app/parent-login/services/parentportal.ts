export class ParentPortal {
    Username= '';
    Password= '';
    key='';
    userType = '';
  static key: string;
  static Username: string;
  static Password: string;
}