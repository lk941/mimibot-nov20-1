export class Score {
    Date: string;
    qns1: number;
    qns2: number;
    Score: number = 0;
    childName: string;
}
