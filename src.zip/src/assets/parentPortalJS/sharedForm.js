angular.module('DemoApp', ['ngMessages']);

angular.bootstrap(document.getElementById('demoApp'), ['DemoApp']);