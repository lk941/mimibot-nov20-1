import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { HomeworkComponent } from './homework/homework.component';
import { QuizComponent } from './quiz/quiz.component';
import { BullyReportComponent } from './bully-report/bully-report.component';
import { BullyDetailsComponent} from './bully-details/bully-details.component';
import { ScoreDetailsComponent } from './pcrassesment/score-details/score-details.component';
import { BullyInsightComponent } from './contatos1/bully-insight/bully-insight.component';
import { ParentLoginComponent } from './parent-login/parent-login.component';
import { ParentportalsignComponent } from './parentportalsign/parentportalsign.component';
import { ChildReportComponent } from './child-report/child-report.component';
import { ChildInsightComponent } from './child-insight/child-insight.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'homework', component: HomeworkComponent },
  { path: 'quiz', component: QuizComponent },
  { path: 'bully-report', component: BullyReportComponent},
  { path: 'bully-details/:id', component: BullyDetailsComponent},
  { path: 'PCRAReport', component: ScoreDetailsComponent},
  { path: 'bully-insight', component: BullyInsightComponent},
  { path: 'parent-login', component: ParentLoginComponent},
  { path: 'parentportalsign', component: ParentportalsignComponent},
  { path: 'child-report', component: ChildReportComponent },
  { path: 'child-insight', component: ChildInsightComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)], 
  exports: [RouterModule]
})
 
export class AppRoutingModule { }
