export class Contato2 {
    Qn: string = '';
    Ans: string = '';
}
