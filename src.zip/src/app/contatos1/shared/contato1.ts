export class Contato1 {
    BullyName: string ='';
    Victim: string ='';
    Date: string ='';
    Location: string='';
    Reason: string='';
    Action: string='';
    BullyType: string='';
}
