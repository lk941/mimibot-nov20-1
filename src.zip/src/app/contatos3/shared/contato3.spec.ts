import { Contato3 } from './contato3';

describe('Contato3', () => {
  it('should create an instance', () => {
    expect(new Contato3()).toBeTruthy();
  });
});
