import { Contato2 } from './contato2';

describe('Contato2', () => {
  it('should create an instance', () => {
    expect(new Contato2()).toBeTruthy();
  });
});
